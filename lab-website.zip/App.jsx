import React, { useState, useEffect } from "react";

// Example lab data.  Each entry represents a single test result.  You can
// extend this array with additional results or replace it entirely with
// your own data.  If you do, ensure that each item has a unique `id`,
// a `date` string, a `test` name, a numeric `value`, and an optional
// `flag` (e.g. "H" to indicate a high result).
const defaultLabs = [
  {
    id: 1,
    date: "2025‑05‑27 04:36",
    test: "SODIUM,S",
    value: 137
  },
  {
    id: 2,
    date: "2025‑05‑27 04:36",
    test: "Potassium",
    value: 3.8
  },
  {
    id: 3,
    date: "2025‑05‑27 04:36",
    test: "CHLORIDE",
    value: 105
  },
  {
    id: 4,
    date: "2025‑05‑27 04:36",
    test: "CO2",
    value: 23
  },
  {
    id: 5,
    date: "2025‑05‑27 04:36",
    test: "GLUCOSE",
    value: 109,
    flag: "H"
  },
  {
    id: 6,
    date: "2025‑05‑27 04:36",
    test: "BUN",
    value: 14
  },
  {
    id: 7,
    date: "2025‑05‑27 04:36",
    test: "CREATININE,S",
    value: 0.68
  },
  {
    id: 8,
    date: "2025‑05‑27 04:36",
    test: "eGFR (NO RACE)",
    value: 123
  },
  {
    id: 9,
    date: "2025‑05‑27 04:36",
    test: "ANION GAP",
    value: 13
  },
  {
    id: 10,
    date: "2025‑05‑27 04:36",
    test: "Calcium, Total",
    value: 8.8
  },
  {
    id: 11,
    date: "2025‑05‑27 04:36",
    test: "PROTEIN,TOTAL",
    value: 7.0
  },
  {
    id: 12,
    date: "2025‑05‑27 04:36",
    test: "ALBUMIN,S",
    value: 3.5
  },
  {
    id: 13,
    date: "2025‑05‑27 04:36",
    test: "Globulin",
    value: 3.5
  },
  {
    id: 14,
    date: "2025‑05‑27 04:36",
    test: "Alkaline phosphatase",
    value: 117,
    flag: "H"
  },
  {
    id: 15,
    date: "2025‑05‑27 04:36",
    test: "AST",
    value: 17
  },
  {
    id: 16,
    date: "2025‑05‑27 04:36",
    test: "ALT",
    value: 21
  },
  {
    id: 17,
    date: "2025‑05‑27 04:36",
    test: "BILIRUBIN, TOTAL",
    value: 0.3
  }
];

function App() {
  // Pull any previously saved results from localStorage; if none exist,
  // start with an empty array.  `myResults` holds the list of pinned labs.
  const [myResults, setMyResults] = useState(() => {
    const saved = localStorage.getItem("myResults");
    return saved ? JSON.parse(saved) : [];
  });

  // Search query for filtering the lab table.
  const [query, setQuery] = useState("");

  // Keep `myResults` persisted in the browser’s localStorage whenever it changes.
  useEffect(() => {
    localStorage.setItem("myResults", JSON.stringify(myResults));
  }, [myResults]);

  // Filter the labs based on the current search query.
  const filteredLabs = defaultLabs.filter((item) => {
    const q = query.toLowerCase().trim();
    if (!q) return true;
    return (
      item.date.toLowerCase().includes(q) ||
      item.test.toLowerCase().includes(q) ||
      String(item.value).toLowerCase().includes(q)
    );
  });

  // Adds a lab to the My Results list if it hasn’t been added already.
  const addResult = (lab) => {
    setMyResults((prev) => {
      if (prev.some((item) => item.id === lab.id)) return prev;
      return [...prev, lab];
    });
  };

  // Removes a lab from My Results by id.
  const removeResult = (id) => {
    setMyResults((prev) => prev.filter((item) => item.id !== id));
  };

  // Generates a CSV string from the current My Results list.
  const generateCSV = () => {
    const header = ["Date", "Test", "Value", "Flag"];
    const rows = myResults.map((item) => [
      item.date,
      item.test,
      item.value,
      item.flag || ""
    ]);
    const lines = [header, ...rows].map((r) => r.join(","));
    return lines.join("\n");
  };

  // Initiates a CSV download of My Results.  Creates a temporary anchor
  // element, triggers a click, then cleans it up.
  const exportCSV = () => {
    const csv = generateCSV();
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "my_results.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 max-w-screen-lg mx-auto">
      <h1 className="text-2xl font-bold mb-4">Lab Search</h1>
      <div className="mb-4">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by date, test or value..."
          className="border px-3 py-2 w-full md:w-1/2 rounded"
        />
      </div>
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-2">All Labs</h2>
        <div className="space-y-2">
          {filteredLabs.length === 0 ? (
            <p className="italic text-gray-500">No results match your search.</p>
          ) : (
            filteredLabs.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between border p-2 rounded"
              >
                <div>
                  <p className="font-medium">{item.test}</p>
                  <p className="text-sm text-gray-600">{item.date}</p>
                </div>
                <div className="flex items-center space-x-4">
                  <span>
                    {item.value}
                    {item.flag ? (
                      <span className="text-red-600 font-bold"> ({item.flag})</span>
                    ) : null}
                  </span>
                  <button
                    onClick={() => addResult(item)}
                    className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
                  >
                    Add
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      <div>
        <h2 className="text-xl font-semibold mb-2">My Results</h2>
        {myResults.length === 0 ? (
          <p className="italic text-gray-500">No saved results yet.</p>
        ) : (
          <div className="space-y-2">
            {myResults.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between border p-2 rounded"
              >
                <div>
                  <p className="font-medium">{item.test}</p>
                  <p className="text-sm text-gray-600">{item.date}</p>
                </div>
                <div className="flex items-center space-x-4">
                  <span>
                    {item.value}
                    {item.flag ? (
                      <span className="text-red-600 font-bold"> ({item.flag})</span>
                    ) : null}
                  </span>
                  <button
                    onClick={() => removeResult(item.id)}
                    className="bg-gray-600 text-white px-3 py-1 rounded hover:bg-gray-700"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
            <div className="pt-4 flex space-x-4">
              <button
                onClick={exportCSV}
                className="bg-green-600 text-white px-3 py-2 rounded hover:bg-green-700"
              >
                Export CSV
              </button>
              <button
                onClick={() => setMyResults([])}
                className="bg-red-600 text-white px-3 py-2 rounded hover:bg-red-700"
              >
                Clear All
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;