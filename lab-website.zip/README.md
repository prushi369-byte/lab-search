# Lab Search Micro‑Site

This small React app lets you explore a set of laboratory results. It stores all data locally in the user’s browser so there’s no backend.  To use it in your own React project, copy the file `App.jsx` into your project’s `src` directory and replace your existing `App.jsx`.

## Features

- **Built‑in data:** This version comes with a handful of example lab results (the list shown on the date `2025‑05‑27 04:36` with various tests and values).
- **Search:** Enter any text in the search box to filter by date, test name, or numeric value.  Filtering happens across all columns.
- **Save results:** Click **Add** on any row to pin it into the **My Results** panel.  Pinned rows are stored in `localStorage` so they persist between visits.
- **Remove results:** Click **Remove** in the **My Results** panel to delete a saved row.
- **Export:** When you have saved at least one item, a **Export CSV** button appears.  Clicking it downloads your saved results as a CSV file.

## Running

1. Create a new React project (e.g. using [Create React App](https://create-react-app.dev/)).
2. Replace the contents of `src/App.jsx` with the contents of the provided `App.jsx` file.
3. Start the development server with `npm start`.  The app will open in your browser.

Feel free to modify `defaultLabs` at the top of the file to include additional lab data.  Each lab object should have the shape:

```js
{
  id: number,        // unique identifier
  date: string,      // date/time of the result in any format
  test: string,      // name of the lab test
  value: number,     // numeric result
  flag?: string      // optional flag (e.g. "H" for high)
}
```
